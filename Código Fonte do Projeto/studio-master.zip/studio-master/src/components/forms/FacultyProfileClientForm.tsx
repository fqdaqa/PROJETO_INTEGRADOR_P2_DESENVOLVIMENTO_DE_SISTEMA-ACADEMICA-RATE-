'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { MOCK_USERS, USER_ROLES } from '@/lib/constants'; 
import { PageHeader } from '../shared/PageHeader';
import { Briefcase } from 'lucide-react';

const facultyProfileFormSchema = z.object({
  userId: z.string({ required_error: "Por favor, selecione um membro do corpo docente." }),
  department: z.string().min(2, { message: "O nome do departamento é obrigatório." }),
  title: z.string().min(2, { message: "O título é obrigatório (ex: Professor)." }),
  officeLocation: z.string().optional(),
  officeHours: z.string().optional(),
  bio: z.string().max(500, { message: "A biografia não pode exceder 500 caracteres." }).optional(),
});

type FacultyProfileFormValues = z.infer<typeof facultyProfileFormSchema>;

const defaultValues: Partial<FacultyProfileFormValues> = {};

export function FacultyProfileClientForm() {
  const { toast } = useToast();
  const form = useForm<FacultyProfileFormValues>({
    resolver: zodResolver(facultyProfileFormSchema),
    defaultValues,
    mode: 'onChange',
  });

  function onSubmit(data: FacultyProfileFormValues) {
    toast({
      title: 'Perfil do Docente Atualizado!',
      description: (
        <pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
          <code className="text-white">{JSON.stringify(data, null, 2)}</code>
        </pre>
      ),
    });
    console.log(data);
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gerenciamento de Perfis de Docentes"
        description="Gerencie os perfis dos membros do corpo docente."
        icon={Briefcase}
      />
      <Card className="max-w-2xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle>Editar Perfil do Docente</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <FormField
                control={form.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Membro do Corpo Docente</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um membro do corpo docente" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {MOCK_USERS.filter(u => u.role === USER_ROLES.teacher).map(teacher => (
                           <SelectItem key={teacher.id} value={teacher.id}>{teacher.name} ({teacher.email})</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Departamento</FormLabel>
                    <FormControl>
                      <Input placeholder="ex: Ciência da Computação" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Título</FormLabel>
                    <FormControl>
                      <Input placeholder="ex: Professor, Professor Associado" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="officeLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Localização do Gabinete (Opcional)</FormLabel>
                    <FormControl>
                      <Input placeholder="ex: Sala 301, Prédio de Ciências" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="officeHours"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Horário de Atendimento (Opcional)</FormLabel>
                    <FormControl>
                      <Input placeholder="ex: Seg 10-12, Qua 13-15 com agendamento" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Biografia (Opcional)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Breve biografia ou interesses de pesquisa..." {...field} rows={4} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full sm:w-auto">Salvar Perfil</Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
