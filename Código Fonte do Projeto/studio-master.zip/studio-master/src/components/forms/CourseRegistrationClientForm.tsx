'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { MOCK_USERS, MOCK_COURSES, USER_ROLES } from '@/lib/constants';
import { PageHeader } from '../shared/PageHeader';
import { ClipboardList } from 'lucide-react';

const courseRegistrationFormSchema = z.object({
  studentId: z.string({ required_error: "Por favor, selecione um aluno." }),
  courseIds: z.array(z.string()).refine((value) => value.some((item) => item), {
    message: "Você deve selecionar pelo menos um curso.",
  }),
  semester: z.string().min(1, {message: "O semestre é obrigatório."}),
});

type CourseRegistrationFormValues = z.infer<typeof courseRegistrationFormSchema>;

const defaultValues: Partial<CourseRegistrationFormValues> = {
  courseIds: [],
};

const semesterOptions = [
  { value: "2024-2", label: "2º Semestre 2024" },
  { value: "2025-1", label: "1º Semestre 2025" },
  { value: "2025-summer", label: "Verão 2025" },
];


export function CourseRegistrationClientForm() {
  const { toast } = useToast();
  const form = useForm<CourseRegistrationFormValues>({
    resolver: zodResolver(courseRegistrationFormSchema),
    defaultValues,
    mode: 'onChange',
  });

  function onSubmit(data: CourseRegistrationFormValues) {
    toast({
      title: 'Inscrição em Cursos Enviada!',
      description: (
        <pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
          <code className="text-white">{JSON.stringify(data, null, 2)}</code>
        </pre>
      ),
    });
    console.log(data);
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Inscrição em Cursos"
        description="Inscreva alunos nos cursos disponíveis."
        icon={ClipboardList}
      />
      <Card className="max-w-2xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle>Nova Inscrição em Cursos</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <FormField
                control={form.control}
                name="studentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Aluno</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um aluno" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {MOCK_USERS.filter(u => u.role === USER_ROLES.student).map(student => (
                           <SelectItem key={student.id} value={student.id}>{student.name} ({student.email})</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="semester"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Semestre</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o semestre" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {semesterOptions.map(option => (
                          <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="courseIds"
                render={() => (
                  <FormItem>
                    <div className="mb-4">
                      <FormLabel className="text-base">Cursos Disponíveis</FormLabel>
                      <FormDescription>
                        Selecione os cursos para inscrição.
                      </FormDescription>
                    </div>
                    <div className="space-y-2">
                    {MOCK_COURSES.map((course) => (
                      <FormField
                        key={course.id}
                        control={form.control}
                        name="courseIds"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={course.id}
                              className="flex flex-row items-start space-x-3 space-y-0"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(course.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...(field.value || []), course.id])
                                      : field.onChange(
                                          field.value?.filter(
                                            (value) => value !== course.id
                                          )
                                        )
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">
                                {course.name} ({course.code}) - {course.credits} créditos
                              </FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full sm:w-auto">Inscrever em Cursos</Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
