'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { CalendarIcon, UserPlus } from "lucide-react"
import { cn } from "@/lib/utils"
import { MOCK_COURSES } from '@/lib/constants'; // Usando cursos como programas simulados por enquanto
import { PageHeader } from '../shared/PageHeader';


const enrollmentFormSchema = z.object({
  studentFullName: z.string().min(2, { message: "O nome completo deve ter pelo menos 2 caracteres." }),
  studentEmail: z.string().email({ message: "Endereço de e-mail inválido." }),
  dateOfBirth: z.date({ required_error: "A data de nascimento é obrigatória."}),
  address: z.string().min(5, { message: "O endereço deve ter pelo menos 5 caracteres." }),
  emergencyContactName: z.string().min(2, { message: "O nome do contato de emergência é obrigatório." }),
  emergencyContactPhone: z.string().regex(/^\+?[1-9]\d{1,14}$/, { message: "Número de telefone inválido." }),
  programId: z.string({ required_error: "Por favor, selecione um programa." }),
});

type EnrollmentFormValues = z.infer<typeof enrollmentFormSchema>;

const defaultValues: Partial<EnrollmentFormValues> = {};

export function EnrollmentClientForm() {
  const { toast } = useToast();
  const form = useForm<EnrollmentFormValues>({
    resolver: zodResolver(enrollmentFormSchema),
    defaultValues,
    mode: 'onChange',
  });

  function onSubmit(data: EnrollmentFormValues) {
    toast({
      title: 'Matrícula Enviada!',
      description: (
        <pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
          <code className="text-white">{JSON.stringify(data, null, 2)}</code>
        </pre>
      ),
    });
    console.log(data);
    // form.reset(); // Opcionalmente resetar formulário
  }

  return (
    <div className="space-y-6">
       <PageHeader
        title="Matrícula de Aluno"
        description="Registre um novo aluno no sistema."
        icon={UserPlus}
      />
      <Card className="max-w-3xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle>Formulário de Matrícula de Novo Aluno</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <FormField
                control={form.control}
                name="studentFullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome Completo do Aluno</FormLabel>
                    <FormControl>
                      <Input placeholder="ex: Maria Silva" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="studentEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email do Aluno</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="aluno@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="dateOfBirth"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Data de Nascimento</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-[240px] pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: ptBR })
                            ) : (
                              <span>Escolha uma data</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) =>
                            date > new Date() || date < new Date("1900-01-01")
                          }
                          initialFocus
                          locale={ptBR}
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Endereço Completo</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Rua Principal, 123, Cidade, Estado" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="emergencyContactName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome do Contato de Emergência</FormLabel>
                    <FormControl>
                      <Input placeholder="ex: João Silva" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="emergencyContactPhone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Telefone do Contato de Emergência</FormLabel>
                    <FormControl>
                      <Input type="tel" placeholder="+5511999999999" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="programId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Programa/Curso</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione um programa" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {MOCK_COURSES.map(course => ( // Usando cursos como programas simulados
                           <SelectItem key={course.id} value={course.id}>{course.name}</SelectItem>
                        ))}
                        <SelectItem value="undeclared">Não Declarado</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full sm:w-auto">Matricular Aluno</Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
