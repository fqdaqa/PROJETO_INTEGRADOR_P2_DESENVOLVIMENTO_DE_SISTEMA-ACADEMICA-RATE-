'use client';

import * as React from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription as ShadCNCardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'; // Renomeado CardDescription para evitar conflito
import { useToast } from '@/hooks/use-toast';
import { getStudentPerformanceSummaryAction } from '@/lib/actions';
import type { StudentPerformanceSummary } from '@/lib/types';
import { Loader2, BrainCircuit } from 'lucide-react';
import { ChartContainer, ChartTooltip, ChartTooltipContent, BarChart, Bar, XAxis, YAxis, CartesianGrid } from '@/components/ui/chart';
import { PageHeader } from '../shared/PageHeader';

const performanceInsightsFormSchema = z.object({
  studentName: z.string().min(2, { message: "O nome do aluno deve ter pelo menos 2 caracteres." }),
  courseRecords: z.string().min(10, { message: "Os registros do curso devem ser fornecidos (ex: Matemática: A, Ciências: B)." }),
});

type PerformanceInsightsFormValues = z.infer<typeof performanceInsightsFormSchema>;

const defaultValues: Partial<PerformanceInsightsFormValues> = {};

// Helper to parse areas of concern for chart
const parseAreasForChart = (areasText: string): { name: string; concern: number }[] => {
  if (!areasText || areasText.toLowerCase().includes("não foi possível determinar") || areasText.toLowerCase().includes("nenhuma área específica")) {
    return [];
  }
  // Simple parsing: split by common delimiters and look for keywords
  const keywords: Record<string, string> = {
    "matemática": "Matemática",
    "ciências": "Ciências",
    "português": "Português",
    "inglês": "Inglês",
    "escrita": "Escrita",
    "leitura": "Leitura",
    "história": "História",
    "resolução de problemas": "Res. Problemas",
    "compreensão": "Compreensão",
    "participação": "Participação",
    "dever de casa": "Dever de Casa",
    "lição de casa": "Lição de Casa",
    "tarefas": "Tarefas"
  };
  const uniqueAreas: Set<string> = new Set();
  
  const segments = areasText.split(/,|\.|;|e /i).map(s => s.trim().toLowerCase());
  
  segments.forEach(segment => {
    for (const keyword in keywords) {
      if (segment.includes(keyword)) {
        uniqueAreas.add(keywords[keyword]); 
      }
    }
  });
  
  if (uniqueAreas.size === 0 && areasText.length > 0) {
     const potentialAreas = areasText.split('. ');
     potentialAreas.slice(0,3).forEach(area => {
        const cleanArea = area.trim();
        if (cleanArea.length > 0) {
            uniqueAreas.add(cleanArea.substring(0,20) + (cleanArea.length > 20 ? '...' : ''))
        }
     });
  }

  return Array.from(uniqueAreas).map(area => ({ name: area, concern: 1 }));
};


export function PerformanceInsightsClient() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const [summaryResult, setSummaryResult] = React.useState<StudentPerformanceSummary | null>(null);
  const [chartData, setChartData] = React.useState<{ name: string; concern: number }[]>([]);


  const form = useForm<PerformanceInsightsFormValues>({
    resolver: zodResolver(performanceInsightsFormSchema),
    defaultValues,
    mode: 'onChange',
  });

  async function onSubmit(data: PerformanceInsightsFormValues) {
    setIsLoading(true);
    setSummaryResult(null);
    setChartData([]);
    try {
      const result = await getStudentPerformanceSummaryAction(data);
      setSummaryResult(result);
      if (result.areasOfConcern) {
        setChartData(parseAreasForChart(result.areasOfConcern));
      }
      toast({
        title: 'Análise Concluída',
        description: 'Resumo de desempenho do aluno gerado.',
      });
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Falha ao gerar resumo de desempenho.',
        variant: 'destructive',
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  }
  
  const chartConfig = {
    concern: {
      label: "Nível de Preocupação",
      color: "hsl(var(--primary))",
    },
  } satisfies Parameters<typeof ChartContainer>[0]["config"];


  return (
    <div className="space-y-6">
      <PageHeader
        title="Análise de Desempenho com IA"
        description="Analise o desempenho dos alunos e preveja áreas de apoio usando IA."
        icon={BrainCircuit}
      />
      <Card className="max-w-3xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle>Análise de Desempenho do Aluno</CardTitle>
          <ShadCNCardDescription>
            Insira os detalhes do aluno para gerar um resumo de desempenho com IA e identificar possíveis áreas de preocupação.
          </ShadCNCardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <FormField
                control={form.control}
                name="studentName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome Completo do Aluno</FormLabel>
                    <FormControl>
                      <Input placeholder="ex: João Silva" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="courseRecords"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Registros de Cursos e Observações</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="ex: Matemática: A, Ciências: B+, História: C. Dificuldade em completar tarefas. Participa bem nas aulas."
                        {...field}
                        rows={4}
                      />
                    </FormControl>
                    <FormDescription>
                      Forneça um resumo de notas, participação, tarefas ou quaisquer observações relevantes.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" disabled={isLoading} className="w-full sm:w-auto">
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Gerar Análise
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {summaryResult && (
        <Card className="max-w-3xl mx-auto mt-8 shadow-lg">
          <CardHeader>
            <CardTitle>Resumo de Desempenho para {form.getValues('studentName')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg text-foreground">Resumo Gerado por IA:</h3>
              <p className="text-muted-foreground whitespace-pre-wrap">{summaryResult.summary}</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg text-foreground">Possíveis Áreas de Preocupação:</h3>
              <p className="text-muted-foreground whitespace-pre-wrap">{summaryResult.areasOfConcern}</p>
            </div>
            
            {chartData.length > 0 && (
               <div className="mt-6">
                <h3 className="font-semibold text-lg text-foreground mb-2">Visualização das Áreas de Preocupação:</h3>
                <ChartContainer config={chartConfig} className="h-[250px] w-full">
                  <BarChart accessibilityLayer data={chartData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="name" 
                      tickLine={false} 
                      axisLine={false} 
                      tickMargin={8}
                      interval={0} 
                      angle={-30} 
                      textAnchor="end"
                      height={50} 
                    />
                    <YAxis 
                      tickLine={false} 
                      axisLine={false} 
                      tickMargin={8}
                      allowDecimals={false}
                      domain={[0, 'dataMax + 1']} 
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="concern" fill="var(--color-concern)" radius={4} />
                  </BarChart>
                </ChartContainer>
               </div>
            )}
            {chartData.length === 0 && summaryResult.areasOfConcern && !summaryResult.areasOfConcern.toLowerCase().includes("não foi possível determinar") && !summaryResult.areasOfConcern.toLowerCase().includes("nenhuma área específica") && (
                <p className="text-sm text-muted-foreground mt-4"><em>Não foi possível gerar automaticamente um gráfico para as áreas de preocupação. Revise a descrição textual.</em></p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
