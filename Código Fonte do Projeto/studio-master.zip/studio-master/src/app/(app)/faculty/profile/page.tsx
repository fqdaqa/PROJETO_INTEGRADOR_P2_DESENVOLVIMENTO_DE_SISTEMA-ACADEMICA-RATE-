import { FacultyProfileClientForm } from '@/components/forms/FacultyProfileClientForm';

export default function FacultyProfilePage() {
  return (
    <FacultyProfileClientForm />
  );
}
