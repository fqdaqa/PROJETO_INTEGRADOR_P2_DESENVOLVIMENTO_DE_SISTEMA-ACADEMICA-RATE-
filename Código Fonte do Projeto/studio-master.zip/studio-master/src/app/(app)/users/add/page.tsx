import { PageHeader } from '@/components/shared/PageHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowLeft, UserPlus } from 'lucide-react';

// Isto será substituído pelo componente UserForm posteriormente
// Por enquanto, é um placeholder

export default function AddUserPage() {
  return (
    <div className="container mx-auto py-2">
      <PageHeader
        title="Adicionar Novo Usuário"
        description="Preencha os detalhes para criar uma nova conta de usuário."
        icon={UserPlus}
        actions={
          <Link href="/users" passHref>
            <Button variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" /> Voltar para Usuários
            </Button>
          </Link>
        }
      />
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Informações do Usuário</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            O formulário de criação de usuário estará aqui. Esta funcionalidade está atualmente em desenvolvimento.
          </p>
          {/* Placeholder para campos do formulário */}
          <div className="mt-6 flex justify-end">
            <Button type="submit" disabled>Salvar Usuário</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
