import { UserTableClient } from '@/components/users/UserTableClient';

export default function UsersPage() {
  return (
    <UserTableClient />
  );
}
