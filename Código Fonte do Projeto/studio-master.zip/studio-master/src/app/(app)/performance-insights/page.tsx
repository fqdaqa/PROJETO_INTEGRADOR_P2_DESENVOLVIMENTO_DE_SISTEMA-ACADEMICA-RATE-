import { PerformanceInsightsClient } from '@/components/performance/PerformanceInsightsClient';

export default function PerformanceInsightsPage() {
  return (
    <PerformanceInsightsClient />
  );
}
