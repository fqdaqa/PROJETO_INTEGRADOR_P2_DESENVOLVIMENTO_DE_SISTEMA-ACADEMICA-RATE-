import { PageHeader } from '@/components/shared/PageHeader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, BookOpen, BarChart3, Settings, LayoutDashboard } from 'lucide-react';
import Link from 'next/link';

const dashboardItems = [
  { title: "Gerenciar Usuários", description: "Visualize, adicione e edite contas de usuário.", icon: Users, href: "/users", cta: "Ir para Usuários" },
  { title: "Catálogo de Cursos", description: "Navegue e gerencie os cursos disponíveis.", icon: BookOpen, href: "/courses", cta: "Ver Cursos" },
  { title: "Desempenho dos Alunos", description: "Analise o progresso e insights dos alunos.", icon: BarChart3, href: "/performance-insights", cta: "Analisar Desempenho" },
  { title: "Configurações do Sistema", description: "Configure as definições da aplicação.", icon: Settings, href: "/settings", cta: "Abrir Configurações", disabled: true },
];

export default function DashboardPage() {
  return (
    <div className="container mx-auto py-2">
      <PageHeader
        title="Painel"
        description="Bem-vindo ao Rate+ Sistema de Gestão Acadêmica. Aqui está uma visão geral."
        icon={LayoutDashboard}
      />
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {dashboardItems.map((item) => (
          <Card key={item.title} className="shadow-lg hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xl font-semibold">{item.title}</CardTitle>
              <item.icon className="h-6 w-6 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <CardDescription className="text-sm mb-4">{item.description}</CardDescription>
              <Link href={item.href} passHref>
                <Button disabled={item.disabled} className="w-full" variant="default">
                  {item.cta}
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
       <Card className="mt-6 shadow-lg">
        <CardHeader>
          <CardTitle>Atividade Recente</CardTitle>
          <CardDescription>Visão geral dos eventos recentes do sistema.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Nenhuma atividade recente para exibir.</p>
          {/* Placeholder para feed de atividades */}
        </CardContent>
      </Card>
    </div>
  );
}
