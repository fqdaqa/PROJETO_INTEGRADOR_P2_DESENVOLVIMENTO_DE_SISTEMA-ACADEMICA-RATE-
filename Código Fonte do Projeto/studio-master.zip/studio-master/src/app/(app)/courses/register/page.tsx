import { CourseRegistrationClientForm } from '@/components/forms/CourseRegistrationClientForm';

export default function CourseRegistrationPage() {
  return (
    <CourseRegistrationClientForm />
  );
}
