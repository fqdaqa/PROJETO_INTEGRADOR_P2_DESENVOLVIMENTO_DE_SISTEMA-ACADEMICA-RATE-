import { EnrollmentClientForm } from '@/components/forms/EnrollmentClientForm';

export default function EnrollmentPage() {
  return (
    <EnrollmentClientForm />
  );
}
