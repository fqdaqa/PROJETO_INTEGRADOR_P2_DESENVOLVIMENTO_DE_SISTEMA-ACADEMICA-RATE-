import type { NavItem, UserRole } from '@/lib/types';
import {
  LayoutDashboard,
  Users,
  UserPlus,
  ClipboardList,
  Briefcase,
  BrainCircuit,
  GraduationCap,
  BookOpen,
  Settings,
} from 'lucide-react';

export const APP_NAME = "Rate+ Sistema de Gestão Acadêmica";

export const USER_ROLES: Record<UserRole, string> = {
  student: 'aluno',
  teacher: 'professor',
  admin: 'administrador',
};

export const NAV_ITEMS: NavItem[] = [
  {
    title: 'Painel',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    title: 'Usuários',
    href: '/users',
    icon: Users,
  },
  {
    title: 'Matrículas',
    href: '/enrollment',
    icon: UserPlus,
  },
  {
    title: 'Inscrição em Cursos',
    href: '/courses/register',
    icon: ClipboardList,
  },
  {
    title: 'Perfis de Docentes',
    href: '/faculty/profile',
    icon: Briefcase,
  },
  {
    title: 'Análise de Desempenho',
    href: '/performance-insights',
    icon: BrainCircuit,
  },
];

export const MOCK_USERS = [
  { id: '1', name: 'Alice Wonderland', email: 'alice@example.com', role: USER_ROLES.student, registrationDate: '2023-01-15' },
  { id: '2', name: 'Bob O Construtor', email: 'bob@example.com', role: USER_ROLES.teacher, registrationDate: '2022-11-20' },
  { id: '3', name: 'Charlie Brown', email: 'charlie@example.com', role: USER_ROLES.admin, registrationDate: '2022-09-01' },
  { id: '4', name: 'Diana Prince', email: 'diana@example.com', role: USER_ROLES.student, registrationDate: '2023-02-10' },
  { id: '5', name: 'Edward Mãos de Tesoura', email: 'edward@example.com', role: USER_ROLES.teacher, registrationDate: '2023-03-05' },
];

export const MOCK_COURSES = [
  { id: 'C001', name: 'Introdução à Ciência da Computação', code: 'CS101', credits: 3 },
  { id: 'C002', name: 'Cálculo I', code: 'MA101', credits: 4 },
  { id: 'C003', name: 'História Mundial', code: 'HI101', credits: 3 },
];

export const MOCK_FACULTY_PROFILES = [
  { id: 'F001', userId: '2', department: 'Ciência da Computação', title: 'Professor Titular', officeHours: 'Seg 10-12, Qua 13-15' },
  { id: 'F002', userId: '5', department: 'Matemática', title: 'Professor Associado', officeHours: 'Ter 9-11, Qui 14-16' },
];
