export type UserRole = 'student' | 'teacher' | 'admin';

export type User = {
  id: string;
  name: string;
  email: string;
  role: UserRole; // Agora usa o tipo UserRole
  registrationDate: string;
};

export type Course = {
  id: string;
  name: string;
  code: string;
  description?: string;
  credits: number;
};

export type Enrollment = {
  id: string;
  studentId: string;
  courseId: string;
  enrollmentDate: string;
  grade?: string;
};

export type FacultyProfile = {
  id: string;
  userId: string; // Links to User
  department: string;
  title: string; // e.g., Professor, Assistant Professor
  bio?: string;
  officeHours?: string;
};

export type StudentPerformanceInput = {
  studentName: string;
  courseRecords: string; // A string describing course records, e.g., "Math: A, Science: B+, History: A-"
};

// Matches the AI flow output
export type StudentPerformanceSummary = {
  summary: string;
  areasOfConcern: string;
};

export type NavItem = {
  title: string;
  href: string;
  icon: React.ElementType;
  disabled?: boolean;
};
