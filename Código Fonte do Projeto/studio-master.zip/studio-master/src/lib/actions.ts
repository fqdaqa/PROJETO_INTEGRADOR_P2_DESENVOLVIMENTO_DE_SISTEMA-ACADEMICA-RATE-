'use server';

import { studentPerformanceSummary as studentPerformanceSummaryFlow } from '@/ai/flows/student-performance-summary';
import type { StudentPerformanceSummaryInput, StudentPerformanceSummaryOutput } from '@/ai/flows/student-performance-summary';

export async function getStudentPerformanceSummaryAction(
  input: StudentPerformanceSummaryInput
): Promise<StudentPerformanceSummaryOutput> {
  try {
    // Você pode adicionar validação ou processamento adicional aqui
    const result = await studentPerformanceSummaryFlow(input);
    return result;
  } catch (error) {
    console.error("Erro em getStudentPerformanceSummaryAction:", error);
    // É uma boa prática retornar um erro estruturado ou lançar um erro personalizado
    // Por simplicidade, retornando uma mensagem de erro genérica no formato esperado
    return {
      summary: "Ocorreu um erro ao gerar o resumo.",
      areasOfConcern: "Não foi possível determinar as áreas de preocupação devido a um erro.",
    };
  }
}
