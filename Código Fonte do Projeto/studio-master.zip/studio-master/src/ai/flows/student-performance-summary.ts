
// This file is machine-generated - edit at your own risk.
'use server';

/**
 * @fileOverview Uma ferramenta de IA que resume o desempenho dos alunos e prevê áreas onde eles podem precisar de apoio extra.
 *
 * - studentPerformanceSummary - Uma função que lida com o resumo do desempenho do aluno.
 * - StudentPerformanceSummaryInput - O tipo de entrada para a função studentPerformanceSummary.
 * - StudentPerformanceSummaryOutput - O tipo de retorno para a função studentPerformanceSummary.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const StudentPerformanceSummaryInputSchema = z.object({
  studentName: z.string().describe('O nome do aluno.'),
  courseRecords: z.string().describe('Uma lista de registros de curso para o aluno, incluindo notas, observações de comportamento, participação, etc.'),
});
export type StudentPerformanceSummaryInput = z.infer<
  typeof StudentPerformanceSummaryInputSchema
>;

const StudentPerformanceSummaryOutputSchema = z.object({
  summary: z.string().describe('Um resumo conciso do desempenho geral do aluno.'),
  areasOfConcern: z
    .string()
    .describe('Áreas potenciais específicas onde o aluno pode estar enfrentando dificuldades ou precisar de apoio adicional.'),
});
export type StudentPerformanceSummaryOutput = z.infer<
  typeof StudentPerformanceSummaryOutputSchema
>;

export async function studentPerformanceSummary(
  input: StudentPerformanceSummaryInput
): Promise<StudentPerformanceSummaryOutput> {
  return studentPerformanceSummaryFlow(input);
}

const prompt = ai.definePrompt({
  name: 'studentPerformanceSummaryPrompt',
  input: {schema: StudentPerformanceSummaryInputSchema},
  output: {schema: StudentPerformanceSummaryOutputSchema},
  prompt: `Você é um assistente de IA especializado em pedagogia e análise de desempenho acadêmico, auxiliando administradores e professores a entenderem melhor o progresso dos alunos.

Com base nos registros fornecidos, analise e resuma o desempenho do(a) aluno(a) {{{studentName}}}.

Seu resumo deve ser objetivo e construtivo. Destaque os pontos fortes e, principalmente, identifique claramente possíveis áreas de preocupação ou dificuldades onde o(a) aluno(a) possa precisar de apoio extra ou intervenção pedagógica. Seja específico ao listar as áreas de preocupação. Se não houver áreas de preocupação evidentes, afirme isso.

Registros do Aluno:
{{{courseRecords}}}
  `,
});

const studentPerformanceSummaryFlow = ai.defineFlow(
  {
    name: 'studentPerformanceSummaryFlow',
    inputSchema: StudentPerformanceSummaryInputSchema,
    outputSchema: StudentPerformanceSummaryOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
