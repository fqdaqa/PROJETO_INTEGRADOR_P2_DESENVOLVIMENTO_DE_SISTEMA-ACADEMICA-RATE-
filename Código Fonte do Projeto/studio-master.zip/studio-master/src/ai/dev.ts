import { config } from 'dotenv';
config();

import '@/ai/flows/student-performance-summary.ts';