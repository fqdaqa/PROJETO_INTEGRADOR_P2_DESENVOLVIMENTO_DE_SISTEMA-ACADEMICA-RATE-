# **App Name**: Academic Flow

## Core Features:

- Centralized Dashboard: Intuitive dashboard for students, teachers, and administrators with quick access to important information.
- Streamlined Forms: User-friendly forms for student enrollment, course registration, and faculty profile management.
- User Management: Display a sortable list of registered users. Admins can view, add, edit, and remove users.
- AI Performance Insights: AI tool that summarizes student performance and predicts areas where they might need extra support, displayed in a simple chart.

## Style Guidelines:

- Primary color: Soft lavender (#E6E6FA) for a calming and educational feel.
- Background color: Light gray (#F0F0F0) for a clean and modern look.
- Accent color: Muted blue (#A9A9D1) to highlight important actions and links.
- Clean and readable sans-serif font for interface elements to ensure clarity and accessibility.
- Simple, geometric icons to represent different sections and actions, maintaining a consistent and modern aesthetic.
- Use a grid-based layout for a structured and responsive design that adapts to different screen sizes.